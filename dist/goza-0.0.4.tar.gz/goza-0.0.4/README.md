# gonzo
A personal Python assistant library

## Overview
This is a working directory for Gonzo, my personal assistant Python library.  Gonzo provides me with tools to accomplish common tasks in my preferred manner.

## Installation
Gonzo is available on pip!

```python
pip install -U gonzo
```