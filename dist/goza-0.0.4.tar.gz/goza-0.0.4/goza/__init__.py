from goza.chart import Chart
from goza.scatter import Scatter