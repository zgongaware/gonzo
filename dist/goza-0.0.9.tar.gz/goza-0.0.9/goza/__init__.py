from goza.chart import Chart
from goza.scatter import Scatter
from goza.bar import Bar
from goza.ecdf import ECDF